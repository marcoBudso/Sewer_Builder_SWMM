"""Dependency-free SWMM network optimisation helpers.

The module deliberately contains no QGIS imports, so the search algorithm and
the INP/RPT handling can be unit tested with a normal Python interpreter.
"""

from __future__ import annotations

import csv
import os
import re
import shutil
from collections import deque
from dataclasses import dataclass, field


_NUMBER = re.compile(r"^[+-]?\d+(?:\.\d+)?(?:[Ee][+-]?\d+)?$")


@dataclass
class OptimizerSettings:
    max_fill_pct: float = 80.0
    max_flood_m3: float = 0.0
    diameters_m: tuple = (0.2, 0.25, 0.3, 0.4, 0.5, 0.6, 0.8, 1.0, 1.2, 1.5, 2.0, 2.5)
    allow_offsets: bool = False
    offset_step_m: float = 0.05
    max_offset_change_m: float = 0.30
    allow_storage: bool = False
    storage_area_factor: float = 1.25
    allow_pumps: bool = False
    pump_flow_factor: float = 1.10
    allow_orifices: bool = False
    orifice_coeff_factor: float = 1.05
    allow_weirs: bool = False
    weir_width_factor: float = 1.10


@dataclass
class Trial:
    run: int
    action: str
    score: float
    flood_m3: float
    overload_pct: float
    accepted: bool
    inp_path: str
    rpt_path: str
    out_path: str


@dataclass
class OptimizerResult:
    best_inp: str
    best_rpt: str
    best_out: str
    feasible: bool
    simulations: int
    trials: list[Trial] = field(default_factory=list)


class InpDocument:
    """Small lossless-enough editor for the tabular SWMM sections we tune."""

    def __init__(self, text):
        self.preamble = []
        self.sections = []
        current = None
        for raw in text.splitlines():
            match = re.match(r"^\s*\[([^]]+)\]\s*$", raw)
            if match:
                current = [match.group(1).upper(), []]
                self.sections.append(current)
            elif current is None:
                self.preamble.append(raw)
            else:
                current[1].append(raw)

    @classmethod
    def read(cls, path):
        with open(path, "r", encoding="utf-8", errors="ignore") as handle:
            return cls(handle.read())

    def clone(self):
        return InpDocument(self.to_text())

    def body(self, name):
        target = name.upper()
        for section_name, lines in self.sections:
            if section_name == target:
                return lines
        return None

    def rows(self, name):
        body = self.body(name) or []
        for index, line in enumerate(body):
            stripped = line.strip()
            if not stripped or stripped.startswith(";"):
                continue
            data, separator, comment = line.partition(";")
            tokens = data.split()
            if tokens:
                yield index, tokens, (separator + comment if separator else "")

    def set_tokens(self, name, index, tokens, comment=""):
        body = self.body(name)
        if body is None:
            return
        line = "  ".join(str(value) for value in tokens)
        if comment:
            line += "  " + comment
        body[index] = line

    def set_option(self, key, value):
        for index, tokens, comment in self.rows("OPTIONS"):
            if tokens[0].upper() == key.upper():
                tokens[1:] = [str(value)]
                self.set_tokens("OPTIONS", index, tokens, comment)
                return

    def to_text(self):
        result = list(self.preamble)
        for name, lines in self.sections:
            result.append("[{}]".format(name))
            result.extend(lines)
        return "\n".join(result) + "\n"

    def write(self, path):
        with open(path, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(self.to_text())


def read_circular_diameters(inp_path):
    """Return final circular XSECTION diameters keyed by SWMM link ID."""
    document = InpDocument.read(inp_path)
    diameters = {}
    for _index, tokens, _comment in document.rows("XSECTIONS"):
        if len(tokens) >= 3 and tokens[1].upper() == "CIRCULAR":
            try:
                diameters[tokens[0]] = float(tokens[2])
            except ValueError:
                pass
    return diameters


def _numeric_tokens(tokens):
    return [float(value) for value in tokens if _NUMBER.match(value)]


def _section_data(lines, title):
    start = next((i for i, line in enumerate(lines) if title.lower() in line.lower()), None)
    if start is None:
        return []
    separators = 0
    data_start = start + 1
    for index in range(start + 1, min(len(lines), start + 80)):
        stripped = lines[index].strip()
        if stripped and set(stripped) <= set("- ") and "-" in stripped:
            separators += 1
            data_start = index + 1
            if separators >= 2:
                break
    output = []
    for line in lines[data_start:]:
        stripped = line.strip()
        if not stripped:
            if output:
                break
            continue
        if ("summary" in stripped.lower() and output) or stripped.startswith(("*", "[")):
            if output:
                break
            continue
        if set(stripped) <= set("- ") or stripped.startswith(";"):
            continue
        output.append(stripped)
    return output


def parse_report(path):
    """Return overload ratios and flooding volumes from a SWMM report."""
    with open(path, "r", encoding="utf-8", errors="ignore") as handle:
        lines = handle.readlines()
    links = {}
    nodes = {}
    for line in _section_data(lines, "Link Flow Summary"):
        parts = line.split()
        values = _numeric_tokens(parts[1:])
        if len(parts) >= 2 and values:
            # The last numeric field in the standard table is Max/Full Depth.
            links[parts[0]] = {"qmax": values[0], "fill_ratio": values[-1] if len(values) >= 4 else None}
    for line in _section_data(lines, "Node Flooding Summary"):
        parts = line.split()
        values = _numeric_tokens(parts[1:])
        if len(parts) >= 2 and values:
            raw_volume = values[-1] if len(values) >= 3 else 0.0
            nodes[parts[0]] = {"flood_m3": max(0.0, raw_volume * 1000.0)}
    return links, nodes


def apply_orifice_flow_limits(document, report_path, relative_tolerance=0.01):
    """Resize flow-limited circular orifices from their simulated peak flow.

    QMAX_LPS metadata is stored in the [ORIFICES] row comment. Because the
    simulated upstream head changes when the outlet changes, callers rerun SWMM
    and invoke this function until it returns no changes.
    """
    links, _nodes = parse_report(report_path)
    targets = {}
    for _index, tokens, comment in document.rows("ORIFICES"):
        match = re.search(r"QMAX_LPS\s*=\s*([0-9.eE+-]+)", comment, re.IGNORECASE)
        if tokens and match:
            target = float(match.group(1))
            if target > 0:
                targets[tokens[0]] = target

    changes = []
    for index, tokens, comment in document.rows("XSECTIONS"):
        if len(tokens) < 3 or tokens[0] not in targets or tokens[1].upper() != "CIRCULAR":
            continue
        simulated = (links.get(tokens[0]) or {}).get("qmax")
        if simulated is None or simulated <= 0:
            continue
        target = targets[tokens[0]]
        error = abs(simulated - target) / target
        if error <= float(relative_tolerance):
            continue
        old_diameter = float(tokens[2])
        calculated = old_diameter * (target / simulated) ** 0.5
        # Limit each correction to keep the coupled storage/outlet iteration
        # stable when the first trial is far from the requested flow.
        new_diameter = max(0.001, min(5.0, max(old_diameter * 0.5, min(old_diameter * 2.0, calculated))))
        new_tokens = list(tokens)
        new_tokens[2] = "{:.6f}".format(new_diameter)
        document.set_tokens("XSECTIONS", index, new_tokens, comment)
        changes.append({
            "link_id": tokens[0], "target_lps": target,
            "simulated_lps": simulated, "old_diameter_m": old_diameter,
            "new_diameter_m": new_diameter, "relative_error": error,
        })
    return changes


def hydraulic_metrics(report_path, settings):
    links, nodes = parse_report(report_path)
    max_ratio = settings.max_fill_pct / 100.0
    overload = {
        link_id: max(0.0, (data.get("fill_ratio") or 0.0) - max_ratio)
        for link_id, data in links.items()
    }
    flooding = {
        node_id: max(0.0, data.get("flood_m3", 0.0) - settings.max_flood_m3)
        for node_id, data in nodes.items()
    }
    overload_sum = sum(overload.values())
    flood_sum = sum(flooding.values())
    # Flooding remains the most severe hydraulic failure, followed by the
    # cumulative excess filling of conduits.
    score = flood_sum * 1_000_000.0 + overload_sum * 10_000.0
    return {
        "score": score,
        "flood_m3": flood_sum,
        "overload_pct": overload_sum * 100.0,
        "critical_links": [key for key, value in overload.items() if value > 1e-9],
        "overload_by_link": overload,
        "flooded_nodes": [key for key, value in flooding.items() if value > 1e-9],
        "feasible": flood_sum <= 1e-9 and overload_sum <= 1e-9,
    }


def upgrade_critical_conduits(document, critical_links, catalogue):
    """Move every overloaded conduit to its next available catalogue size."""
    conduit_ids = {
        tokens[0] for _index, tokens, _comment in document.rows("CONDUITS") if tokens
    }
    critical = set(critical_links) & conduit_ids
    sizes = sorted(set(float(value) for value in catalogue))
    changed = document.clone()
    upgrades = []
    for index, tokens, comment in document.rows("XSECTIONS"):
        if len(tokens) < 3 or tokens[0] not in critical or tokens[1].upper() != "CIRCULAR":
            continue
        try:
            old = float(tokens[2])
        except ValueError:
            continue
        new = next((diameter for diameter in sizes if diameter > old + 1e-9), None)
        if new is None:
            continue
        new_tokens = list(tokens)
        new_tokens[2] = "{:.3f}".format(new)
        changed.set_tokens("XSECTIONS", index, new_tokens, comment)
        upgrades.append((tokens[0], old, new))
    return changed, upgrades


def candidate_changes(document, metrics, settings, cumulative):
    """Yield hydraulic alternatives without assigning an economic cost."""
    critical = set(metrics["critical_links"])
    flooded = set(metrics["flooded_nodes"])
    if settings.allow_offsets:
        for index, tokens, comment in document.rows("CONDUITS"):
            if len(tokens) < 7 or tokens[0] not in critical:
                continue
            used = cumulative.get("offset:" + tokens[0], 0.0)
            if used + settings.offset_step_m > settings.max_offset_change_m + 1e-9:
                continue
            try:
                old = float(tokens[5])
            except ValueError:
                continue
            changed = document.clone()
            new_tokens = list(tokens)
            new_tokens[5] = "{:.3f}".format(old + settings.offset_step_m)
            changed.set_tokens("CONDUITS", index, new_tokens, comment)
            yield "Offset monte {}: +{:.3f} m".format(tokens[0], settings.offset_step_m), changed

    if settings.allow_storage:
        storage_nodes = set()
        for _index, tokens, _comment in document.rows("STORAGE"):
            if tokens:
                storage_nodes.add(tokens[0])
        curves = {}
        current_curve = None
        for index, tokens, comment in document.rows("CURVES"):
            if len(tokens) >= 4 and tokens[1].upper() == "STORAGE":
                current_curve = tokens[0]
            if current_curve and len(tokens) >= 3:
                curves.setdefault(current_curve, []).append((index, tokens, comment))
        for _index, storage, _comment in document.rows("STORAGE"):
            if not storage or storage[0] not in flooded or len(storage) < 6:
                continue
            curve_name = storage[5]
            if curve_name not in curves:
                continue
            changed = document.clone()
            for row_index, tokens, comment in curves[curve_name]:
                new_tokens = list(tokens)
                try:
                    new_tokens[-1] = "{:.3f}".format(float(tokens[-1]) * settings.storage_area_factor)
                except ValueError:
                    continue
                changed.set_tokens("CURVES", row_index, new_tokens, comment)
            yield "Storage {}: area x{:.2f}".format(storage[0], settings.storage_area_factor), changed

    if settings.allow_pumps:
        pump_curves = {tokens[4] for _i, tokens, _c in document.rows("PUMPS") if len(tokens) >= 5}
        curve_rows = {}
        for index, tokens, comment in document.rows("CURVES"):
            if len(tokens) >= 3 and tokens[0] in pump_curves:
                curve_rows.setdefault(tokens[0], []).append((index, tokens, comment))
        for curve_name, rows in curve_rows.items():
            changed = document.clone()
            valid = False
            for index, tokens, comment in rows:
                new_tokens = list(tokens)
                try:
                    new_tokens[-1] = "{:.3f}".format(float(tokens[-1]) * settings.pump_flow_factor)
                except ValueError:
                    continue
                changed.set_tokens("CURVES", index, new_tokens, comment)
                valid = True
            if valid:
                yield "Curva pompa {}: portata x{:.2f}".format(curve_name, settings.pump_flow_factor), changed

    if settings.allow_orifices:
        for index, tokens, comment in document.rows("ORIFICES"):
            if len(tokens) < 6:
                continue
            if "QMAX_LPS=" in comment.upper():
                continue
            changed = document.clone()
            new_tokens = list(tokens)
            try:
                new_tokens[5] = "{:.3f}".format(float(tokens[5]) * settings.orifice_coeff_factor)
            except ValueError:
                continue
            changed.set_tokens("ORIFICES", index, new_tokens, comment)
            yield "Orifizio {}: coefficiente x{:.2f}".format(tokens[0], settings.orifice_coeff_factor), changed

    if settings.allow_weirs:
        weir_ids = {tokens[0] for _i, tokens, _c in document.rows("WEIRS") if tokens}
        for index, tokens, comment in document.rows("XSECTIONS"):
            if len(tokens) < 4 or tokens[0] not in weir_ids:
                continue
            changed = document.clone()
            new_tokens = list(tokens)
            try:
                new_tokens[2] = "{:.3f}".format(float(tokens[2]) * settings.weir_width_factor)
            except ValueError:
                continue
            changed.set_tokens("XSECTIONS", index, new_tokens, comment)
            yield "Soglia {}: larghezza x{:.2f}".format(tokens[0], settings.weir_width_factor), changed


def network_stages(document):
    """Group gravity conduits between special elements, upstream to downstream.

    Link direction is taken from the INP node endpoints, not from row order.
    A storage node forms a barrier before its outgoing link; pumps, orifices
    and weirs form barriers at their link position. Converging branches at
    the same distance are processed together in deterministic ID order.
    """
    links = {}
    incoming = {}
    for section in ("CONDUITS", "PUMPS", "WEIRS", "ORIFICES"):
        for _index, tokens, _comment in document.rows(section):
            if len(tokens) >= 3:
                link_id, upstream, downstream = tokens[:3]
                links[link_id] = (section, upstream, downstream)
                incoming.setdefault(downstream, []).append(upstream)
    outfalls = [tokens[0] for _i, tokens, _c in document.rows("OUTFALLS") if tokens]
    distance = {node: 0 for node in outfalls}
    queue = deque(outfalls)
    while queue:
        node = queue.popleft()
        for upstream in incoming.get(node, ()):
            if upstream not in distance:
                distance[upstream] = distance[node] + 1
                queue.append(upstream)
    storage = {tokens[0] for _i, tokens, _c in document.rows("STORAGE") if tokens}
    events = []
    for node in storage:
        events.append((node, "STORAGE", node, node))
    for link_id, (section, upstream, downstream) in links.items():
        events.append((link_id, section, upstream, downstream))
    # At a storage, pause before processing any of its outgoing conduits or
    # controls. At special links, pause before the next conduit downstream.
    events.sort(key=lambda event: (
        -distance.get(event[2], -1),
        0 if event[1] == "STORAGE" else (1 if event[1] != "CONDUITS" else 2),
        event[0],
    ))
    stages = []
    pipes = []
    for element_id, section, _upstream, _downstream in events:
        if section == "CONDUITS":
            pipes.append(element_id)
        else:
            if pipes:
                stages.append(("CONDUITS", tuple(pipes)))
                pipes = []
            stages.append((section, element_id))
    if pipes:
        stages.append(("CONDUITS", tuple(pipes)))
    return stages


def special_candidates(document, metrics, settings, cumulative, section, element_id):
    """Use the unchanged 1.2.4 control changes at the encountered element."""
    if section == "STORAGE":
        if not settings.allow_storage:
            return []
        # Upstream flooding can be relieved by a storage which itself does
        # not flood, so include the encountered storage as a local candidate.
        local_metrics = dict(metrics)
        local_metrics["flooded_nodes"] = list(set(metrics["flooded_nodes"]) | {element_id})
        label = "Storage {}:".format(element_id)
    elif section == "PUMPS":
        if not settings.allow_pumps:
            return []
        curve = next((tokens[4] for _i, tokens, _c in document.rows("PUMPS")
                      if len(tokens) >= 5 and tokens[0] == element_id), None)
        if not curve:
            return []
        local_metrics = metrics
        label = "Curva pompa {}:".format(curve)
    elif section == "ORIFICES":
        if not settings.allow_orifices:
            return []
        local_metrics = metrics
        label = "Orifizio {}:".format(element_id)
    elif section == "WEIRS":
        if not settings.allow_weirs:
            return []
        local_metrics = metrics
        label = "Soglia {}:".format(element_id)
    else:
        return []
    return [(action, candidate) for action, candidate in
            candidate_changes(document, local_metrics, settings, cumulative)
            if action.startswith(label)]


def optimize(base_inp, initial_rpt, output_dir, settings, run_solver, progress=None):
    """Iteratively minimise hydraulic failures. ``run_solver`` runs SWMM."""
    os.makedirs(output_dir, exist_ok=True)
    current = InpDocument.read(base_inp)
    current_metrics = hydraulic_metrics(initial_rpt, settings)
    cumulative = {}
    trials = []
    simulations = 0
    best_rpt = initial_rpt
    best_out = ""
    stages = network_stages(current)
    special_attempts = {}

    def simulate(candidate, action):
        nonlocal simulations
        simulations += 1
        stem = "trial_{:03d}".format(simulations)
        inp_path = os.path.join(output_dir, stem + ".inp")
        rpt_path = os.path.join(output_dir, stem + ".rpt")
        out_path = os.path.join(output_dir, stem + ".out")
        candidate.write(inp_path)
        run_solver(inp_path, rpt_path, out_path)
        metrics = hydraulic_metrics(rpt_path, settings)
        trial = Trial(simulations, action, metrics["score"], metrics["flood_m3"],
                      metrics["overload_pct"], False, inp_path, rpt_path, out_path)
        trials.append(trial)
        if progress:
            progress(simulations, action, metrics)
        return metrics, trial

    while not current_metrics["feasible"]:
        changed_in_pass = False
        for section, element in stages:
            if current_metrics["feasible"]:
                break
            if section == "CONDUITS":
                # Keep the 1.2.4 intervention intact: advance all critical
                # conduits in this stretch together to the next catalogue DN.
                affected = set(element) & set(current_metrics["critical_links"])
                diameter_candidate, upgrades = upgrade_critical_conduits(
                    current, affected, settings.diameters_m
                )
                if not upgrades:
                    continue
                action = "Incremento diametri: " + ", ".join(
                    "{} {:.3f}->{:.3f} m".format(link_id, old, new)
                    for link_id, old, new in upgrades
                )
                metrics, trial = simulate(diameter_candidate, action)
                # The original 1.2.4 accepts its diameter step unconditionally.
                trial.accepted = True
                current, current_metrics = diameter_candidate, metrics
                best_rpt, best_out = trial.rpt_path, trial.out_path
                changed_in_pass = True
                continue

            key = (section, element)
            if special_attempts.get(key, 0) >= 5:
                continue
            candidates = special_candidates(
                current, current_metrics, settings, cumulative, section, element
            )
            # Complete the local special-element trial before moving on to
            # the next conduit stretch. An ineffective change is not retained.
            for action, candidate in candidates:
                special_attempts[key] = special_attempts.get(key, 0) + 1
                metrics, trial = simulate(candidate, action)
                if metrics["score"] < current_metrics["score"] - 1e-9:
                    trial.accepted = True
                    current, current_metrics = candidate, metrics
                    best_rpt, best_out = trial.rpt_path, trial.out_path
                    changed_in_pass = True
                break

        if changed_in_pass:
            continue

        best = None
        # Preserve the 1.2.4 offset fallback only when neither pipe stretches
        # nor encountered special elements can advance further.
        candidates = [(action, candidate) for action, candidate in
                      candidate_changes(current, current_metrics, settings, cumulative)
                      if action.startswith("Offset monte ")]
        if not candidates:
            break
        for action, candidate in candidates:
            metrics, trial = simulate(candidate, action)
            total_diameter = sum(
                float(row[1][2]) for row in candidate.rows("XSECTIONS")
                if len(row[1]) >= 3 and row[1][1].upper() == "CIRCULAR"
            )
            rank = (0 if metrics["feasible"] else 1, metrics["score"], total_diameter)
            if best is None or rank < best[0]:
                best = (rank, candidate, metrics, trial)
        if best is None:
            break
        _rank, candidate, candidate_metrics, accepted_trial = best
        # Diameter plateaus are handled above by advancing through the finite
        # catalogue. Once no diameter can advance, an auxiliary intervention is
        # accepted only if it strictly improves the hydraulic result; otherwise
        # the available configuration cannot converge and the loop terminates.
        if candidate_metrics["score"] >= current_metrics["score"] - 1e-9:
            break
        current, current_metrics = candidate, candidate_metrics
        accepted_trial.accepted = True
        best_rpt = accepted_trial.rpt_path
        best_out = accepted_trial.out_path
        if accepted_trial.action.startswith("Offset monte "):
            link_id = accepted_trial.action.split()[2].rstrip(":")
            cumulative["offset:" + link_id] = cumulative.get("offset:" + link_id, 0.0) + settings.offset_step_m

    best_inp = os.path.join(output_dir, "modello_swmm_ottimizzato.inp")
    current.write(best_inp)
    final_rpt = os.path.join(output_dir, "modello_swmm_ottimizzato.rpt")
    final_out = os.path.join(output_dir, "modello_swmm_ottimizzato.out")
    if os.path.exists(best_rpt):
        shutil.copy2(best_rpt, final_rpt)
    if best_out and os.path.exists(best_out):
        shutil.copy2(best_out, final_out)
    csv_path = os.path.join(output_dir, "riepilogo_ottimizzazione.csv")
    with open(csv_path, "w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.writer(handle, delimiter=";")
        writer.writerow(["run", "azione", "punteggio_idraulico", "esondazione_m3", "sovraccarico_pct", "accettata", "file_inp"])
        for trial in trials:
            writer.writerow([trial.run, trial.action, trial.score, trial.flood_m3, trial.overload_pct, "SI" if trial.accepted else "NO", trial.inp_path])
    return OptimizerResult(best_inp, final_rpt if os.path.exists(final_rpt) else best_rpt, final_out if os.path.exists(final_out) else best_out, current_metrics["feasible"], simulations, trials)
