"""Dependency-free SWMM network optimisation helpers.

The module deliberately contains no QGIS imports, so the search algorithm and
the INP/RPT handling can be unit tested with a normal Python interpreter.
"""

from __future__ import annotations

import csv
import hashlib
import math
import os
import re
import shutil
from collections import deque
from dataclasses import dataclass, field


_NUMBER = re.compile(r"^[+-]?\d+(?:\.\d+)?(?:[Ee][+-]?\d+)?$")


@dataclass
class OptimizerSettings:
    max_fill_pct: float = 80.0
    max_flood_m3: float = 0.0
    diameters_m: tuple = (0.2, 0.25, 0.3, 0.4, 0.5, 0.6, 0.8, 1.0, 1.2, 1.5, 2.0, 2.5)
    allow_offsets: bool = False
    offset_step_m: float = 0.05
    max_offset_change_m: float = 0.30
    allow_storage: bool = False
    storage_area_factor: float = 1.25
    allow_pumps: bool = False
    pump_flow_factor: float = 1.10
    allow_orifices: bool = False
    orifice_coeff_factor: float = 1.05
    allow_weirs: bool = False
    weir_width_factor: float = 1.10
    storage_ids: tuple = ()
    pump_ids: tuple = ()
    orifice_ids: tuple = ()
    weir_ids: tuple = ()
    max_continuity_error_pct: float = 5.0
    max_simulations: int = 120
    search_width: int = 3
    pump_max_factor: float = 2.0
    weir_max_factor: float = 2.0
    orifice_max_coeff: float = 1.0


@dataclass
class Trial:
    run: int
    action: str
    score: float
    flood_m3: float
    overload_pct: float
    accepted: bool
    inp_path: str
    rpt_path: str
    out_path: str
    reason: str = ""


@dataclass
class OptimizerResult:
    best_inp: str
    best_rpt: str
    best_out: str
    feasible: bool
    simulations: int
    trials: list[Trial] = field(default_factory=list)


class InpDocument:
    """Small lossless-enough editor for the tabular SWMM sections we tune."""

    def __init__(self, text):
        self.preamble = []
        self.sections = []
        current = None
        for raw in text.splitlines():
            match = re.match(r"^\s*\[([^]]+)\]\s*$", raw)
            if match:
                current = [match.group(1).upper(), []]
                self.sections.append(current)
            elif current is None:
                self.preamble.append(raw)
            else:
                current[1].append(raw)

    @classmethod
    def read(cls, path):
        with open(path, "r", encoding="utf-8", errors="ignore") as handle:
            return cls(handle.read())

    def clone(self):
        return InpDocument(self.to_text())

    def body(self, name):
        target = name.upper()
        for section_name, lines in self.sections:
            if section_name == target:
                return lines
        return None

    def rows(self, name):
        body = self.body(name) or []
        for index, line in enumerate(body):
            stripped = line.strip()
            if not stripped or stripped.startswith(";"):
                continue
            data, separator, comment = line.partition(";")
            tokens = data.split()
            if tokens:
                yield index, tokens, (separator + comment if separator else "")

    def set_tokens(self, name, index, tokens, comment=""):
        body = self.body(name)
        if body is None:
            return
        line = "  ".join(str(value) for value in tokens)
        if comment:
            line += "  " + comment
        body[index] = line

    def set_option(self, key, value):
        for index, tokens, comment in self.rows("OPTIONS"):
            if tokens[0].upper() == key.upper():
                tokens[1:] = [str(value)]
                self.set_tokens("OPTIONS", index, tokens, comment)
                return

    def to_text(self):
        result = list(self.preamble)
        for name, lines in self.sections:
            result.append("[{}]".format(name))
            result.extend(lines)
        return "\n".join(result) + "\n"

    def write(self, path):
        with open(path, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(self.to_text())


def read_circular_diameters(inp_path):
    """Return final circular XSECTION diameters keyed by SWMM link ID."""
    document = InpDocument.read(inp_path)
    diameters = {}
    for _index, tokens, _comment in document.rows("XSECTIONS"):
        if len(tokens) >= 3 and tokens[1].upper() == "CIRCULAR":
            try:
                diameters[tokens[0]] = float(tokens[2])
            except ValueError:
                pass
    return diameters


def _numeric_tokens(tokens):
    return [float(value) for value in tokens if _NUMBER.match(value)]


def _section_data(lines, title):
    start = next((i for i, line in enumerate(lines) if title.lower() in line.lower()), None)
    if start is None:
        return []
    separators = 0
    data_start = start + 1
    for index in range(start + 1, min(len(lines), start + 80)):
        stripped = lines[index].strip()
        if stripped and set(stripped) <= set("- ") and "-" in stripped:
            separators += 1
            data_start = index + 1
            if separators >= 2:
                break
    output = []
    for line in lines[data_start:]:
        stripped = line.strip()
        if not stripped:
            if output:
                break
            continue
        if ("summary" in stripped.lower() and output) or stripped.startswith(("*", "[")):
            if output:
                break
            continue
        if set(stripped) <= set("- ") or stripped.startswith(";"):
            continue
        output.append(stripped)
    return output


def parse_report(path):
    """Return overload ratios and flooding volumes from a SWMM report."""
    with open(path, "r", encoding="utf-8", errors="ignore") as handle:
        lines = handle.readlines()
    links = {}
    nodes = {}
    for line in _section_data(lines, "Link Flow Summary"):
        parts = line.split()
        values = _numeric_tokens(parts[1:])
        if len(parts) >= 2 and values:
            # The last numeric field in the standard table is Max/Full Depth.
            links[parts[0]] = {"qmax": values[0], "fill_ratio": values[-1] if len(values) >= 4 else None}
    for line in _section_data(lines, "Node Flooding Summary"):
        parts = line.split()
        values = _numeric_tokens(parts[1:])
        if len(parts) >= 2 and len(values) >= 5:
            # SWMM's standard table ends with Flood Volume [10^6 litres]
            # followed by Ponded Depth [m]. The latter is zero when ponding
            # is disabled, even for a node that lost a substantial volume.
            raw_volume = values[-2]
            nodes[parts[0]] = {"flood_m3": max(0.0, raw_volume * 1000.0)}
    return links, nodes


def routing_continuity_error(path):
    """Read the flow-routing mass balance, not the runoff balance."""
    with open(path, "r", encoding="utf-8", errors="ignore") as handle:
        text = handle.read()
    section = re.search(r"Flow Routing Continuity\b", text, re.IGNORECASE)
    if not section:
        return None
    match = re.search(r"Continuity Error\s*\(%\)\s*\.{0,}\s*([+-]?\d+(?:\.\d+)?)",
                      text[section.end():section.end() + 2500], re.IGNORECASE)
    return float(match.group(1)) if match else None


def apply_orifice_flow_limits(document, report_path, relative_tolerance=0.01):
    """Resize flow-limited circular orifices from their simulated peak flow.

    QMAX_LPS metadata is stored in the [ORIFICES] row comment. Because the
    simulated upstream head changes when the outlet changes, callers rerun SWMM
    and invoke this function until it returns no changes.
    """
    links, _nodes = parse_report(report_path)
    targets = {}
    for _index, tokens, comment in document.rows("ORIFICES"):
        match = re.search(r"QMAX_LPS\s*=\s*([0-9.eE+-]+)", comment, re.IGNORECASE)
        if tokens and match:
            target = float(match.group(1))
            if target > 0:
                targets[tokens[0]] = target

    changes = []
    for index, tokens, comment in document.rows("XSECTIONS"):
        if len(tokens) < 3 or tokens[0] not in targets or tokens[1].upper() != "CIRCULAR":
            continue
        simulated = (links.get(tokens[0]) or {}).get("qmax")
        if simulated is None or simulated <= 0:
            continue
        target = targets[tokens[0]]
        error = abs(simulated - target) / target
        if error <= float(relative_tolerance):
            continue
        old_diameter = float(tokens[2])
        calculated = old_diameter * (target / simulated) ** 0.5
        # Limit each correction to keep the coupled storage/outlet iteration
        # stable when the first trial is far from the requested flow.
        new_diameter = max(0.001, min(5.0, max(old_diameter * 0.5, min(old_diameter * 2.0, calculated))))
        new_tokens = list(tokens)
        new_tokens[2] = "{:.6f}".format(new_diameter)
        document.set_tokens("XSECTIONS", index, new_tokens, comment)
        changes.append({
            "link_id": tokens[0], "target_lps": target,
            "simulated_lps": simulated, "old_diameter_m": old_diameter,
            "new_diameter_m": new_diameter, "relative_error": error,
        })
    return changes


def hydraulic_metrics(report_path, settings):
    links, nodes = parse_report(report_path)
    max_ratio = settings.max_fill_pct / 100.0
    overload = {
        link_id: max(0.0, (data.get("fill_ratio") or 0.0) - max_ratio)
        for link_id, data in links.items()
    }
    flooding = {
        node_id: max(0.0, data.get("flood_m3", 0.0) - settings.max_flood_m3)
        for node_id, data in nodes.items()
    }
    overload_sum = sum(overload.values())
    flood_sum = sum(flooding.values())
    # Flooding remains the most severe hydraulic failure, followed by the
    # cumulative excess filling of conduits.
    score = flood_sum * 1_000_000.0 + overload_sum * 10_000.0
    continuity_error = routing_continuity_error(report_path)
    reliable = (continuity_error is None or
                abs(continuity_error) <= settings.max_continuity_error_pct)
    return {
        "score": score if reliable else float("inf"),
        "continuity_error_pct": continuity_error,
        "reliable": reliable,
        "flood_m3": flood_sum,
        "overload_pct": overload_sum * 100.0,
        "critical_links": [key for key, value in overload.items() if value > 1e-9],
        "overload_by_link": overload,
        "flooded_nodes": [key for key, value in flooding.items() if value > 1e-9],
        "flood_by_node": flooding,
        "feasible": reliable and flood_sum <= 1e-9 and overload_sum <= 1e-9,
    }


def upgrade_critical_conduits(document, critical_links, catalogue):
    """Move every overloaded conduit to its next available catalogue size."""
    conduit_ids = {
        tokens[0] for _index, tokens, _comment in document.rows("CONDUITS") if tokens
    }
    critical = set(critical_links) & conduit_ids
    sizes = sorted(set(float(value) for value in catalogue))
    changed = document.clone()
    upgrades = []
    for index, tokens, comment in document.rows("XSECTIONS"):
        if len(tokens) < 3 or tokens[0] not in critical or tokens[1].upper() != "CIRCULAR":
            continue
        try:
            old = float(tokens[2])
        except ValueError:
            continue
        new = next((diameter for diameter in sizes if diameter > old + 1e-9), None)
        if new is None:
            continue
        new_tokens = list(tokens)
        new_tokens[2] = "{:.3f}".format(new)
        changed.set_tokens("XSECTIONS", index, new_tokens, comment)
        upgrades.append((tokens[0], old, new))
    return changed, upgrades


def candidate_changes(document, metrics, settings, cumulative):
    """Yield hydraulic alternatives without assigning an economic cost."""
    critical = set(metrics["critical_links"])
    flooded = set(metrics["flooded_nodes"])
    if settings.allow_offsets:
        for index, tokens, comment in document.rows("CONDUITS"):
            if len(tokens) < 7 or tokens[0] not in critical:
                continue
            used = cumulative.get("offset:" + tokens[0], 0.0)
            if used + settings.offset_step_m > settings.max_offset_change_m + 1e-9:
                continue
            try:
                old = float(tokens[5])
            except ValueError:
                continue
            changed = document.clone()
            new_tokens = list(tokens)
            new_tokens[5] = "{:.3f}".format(old + settings.offset_step_m)
            changed.set_tokens("CONDUITS", index, new_tokens, comment)
            yield "Offset monte {}: +{:.3f} m".format(tokens[0], settings.offset_step_m), changed

    if settings.allow_storage:
        curves = {}
        storage_curve_names = {tokens[5] for _i, tokens, _c in document.rows("STORAGE")
                               if len(tokens) >= 6 and tokens[4].upper() == "TABULAR"}
        for index, tokens, comment in document.rows("CURVES"):
            if len(tokens) < 3 or tokens[0] not in storage_curve_names:
                continue
            # Never carry a previous storage curve name into subsequent pump
            # curves. Continuation rows have the same name and no Type token.
            if len(tokens) >= 4 and tokens[1].upper() != "STORAGE":
                continue
            curves.setdefault(tokens[0], []).append((index, tokens, comment))
        for _index, storage, _comment in document.rows("STORAGE"):
            if (len(storage) < 6 or storage[0] not in flooded or
                    storage[0] not in settings.storage_ids or storage[4].upper() != "TABULAR"):
                continue
            curve_name = storage[5]
            if curve_name not in curves:
                continue
            changed = document.clone()
            valid = False
            for row_index, tokens, comment in curves[curve_name]:
                new_tokens = list(tokens)
                try:
                    new_tokens[-1] = "{:.3f}".format(float(tokens[-1]) * settings.storage_area_factor)
                except ValueError:
                    continue
                changed.set_tokens("CURVES", row_index, new_tokens, comment)
                valid = True
            if valid:
                yield "Storage {}: area x{:.2f}".format(storage[0], settings.storage_area_factor), changed

    if settings.allow_pumps:
        pump_curves = {tokens[4] for _i, tokens, _c in document.rows("PUMPS") if len(tokens) >= 5}
        curve_rows = {}
        for index, tokens, comment in document.rows("CURVES"):
            if len(tokens) >= 3 and tokens[0] in pump_curves:
                curve_rows.setdefault(tokens[0], []).append((index, tokens, comment))
        for curve_name, rows in curve_rows.items():
            changed = document.clone()
            valid = False
            for index, tokens, comment in rows:
                new_tokens = list(tokens)
                try:
                    new_tokens[-1] = "{:.3f}".format(float(tokens[-1]) * settings.pump_flow_factor)
                except ValueError:
                    continue
                changed.set_tokens("CURVES", index, new_tokens, comment)
                valid = True
            if valid:
                yield "Curva pompa {}: portata x{:.2f}".format(curve_name, settings.pump_flow_factor), changed

    if settings.allow_orifices:
        for index, tokens, comment in document.rows("ORIFICES"):
            if len(tokens) < 6:
                continue
            if "QMAX_LPS=" in comment.upper():
                continue
            changed = document.clone()
            new_tokens = list(tokens)
            try:
                new_tokens[5] = "{:.3f}".format(float(tokens[5]) * settings.orifice_coeff_factor)
            except ValueError:
                continue
            changed.set_tokens("ORIFICES", index, new_tokens, comment)
            yield "Orifizio {}: coefficiente x{:.2f}".format(tokens[0], settings.orifice_coeff_factor), changed

    if settings.allow_weirs:
        weir_ids = {tokens[0] for _i, tokens, _c in document.rows("WEIRS") if tokens}
        for index, tokens, comment in document.rows("XSECTIONS"):
            if len(tokens) < 4 or tokens[0] not in weir_ids:
                continue
            changed = document.clone()
            new_tokens = list(tokens)
            try:
                new_tokens[2] = "{:.3f}".format(float(tokens[2]) * settings.weir_width_factor)
            except ValueError:
                continue
            changed.set_tokens("XSECTIONS", index, new_tokens, comment)
            yield "Soglia {}: larghezza x{:.2f}".format(tokens[0], settings.weir_width_factor), changed


def network_stages(document):
    """Group gravity conduits between special elements, upstream to downstream.

    Link direction is taken from the INP node endpoints, not from row order.
    A storage node forms a barrier before its outgoing link; pumps, orifices
    and weirs form barriers at their link position. Converging branches at
    the same distance are processed together in deterministic ID order.
    """
    links = {}
    incoming = {}
    for section in ("CONDUITS", "PUMPS", "WEIRS", "ORIFICES"):
        for _index, tokens, _comment in document.rows(section):
            if len(tokens) >= 3:
                link_id, upstream, downstream = tokens[:3]
                links[link_id] = (section, upstream, downstream)
                incoming.setdefault(downstream, []).append(upstream)
    outfalls = [tokens[0] for _i, tokens, _c in document.rows("OUTFALLS") if tokens]
    distance = {node: 0 for node in outfalls}
    queue = deque(outfalls)
    while queue:
        node = queue.popleft()
        for upstream in incoming.get(node, ()):
            if upstream not in distance:
                distance[upstream] = distance[node] + 1
                queue.append(upstream)
    storage = {tokens[0] for _i, tokens, _c in document.rows("STORAGE") if tokens}
    events = []
    for node in storage:
        events.append((node, "STORAGE", node, node))
    for link_id, (section, upstream, downstream) in links.items():
        events.append((link_id, section, upstream, downstream))
    # At a storage, pause before processing any of its outgoing conduits or
    # controls. At special links, pause before the next conduit downstream.
    events.sort(key=lambda event: (
        -distance.get(event[2], -1),
        0 if event[1] == "STORAGE" else (1 if event[1] != "CONDUITS" else 2),
        event[0],
    ))
    stages = []
    pipes = []
    for element_id, section, _upstream, _downstream in events:
        if section == "CONDUITS":
            pipes.append(element_id)
        else:
            if pipes:
                stages.append(("CONDUITS", tuple(pipes)))
                pipes = []
            stages.append((section, element_id))
    if pipes:
        stages.append(("CONDUITS", tuple(pipes)))
    return stages


def storage_feeder_conduits(document, selected_storage):
    """Identify gravity links draining to each selected storage, without crossing controls."""
    incoming = {}
    for _index, tokens, _comment in document.rows("CONDUITS"):
        if len(tokens) >= 3:
            incoming.setdefault(tokens[2], []).append((tokens[0], tokens[1]))
    barriers = {tokens[0] for _i, tokens, _c in document.rows("STORAGE") if tokens}
    feeders = {}
    for storage_id in selected_storage:
        seen = set()
        queue = deque([storage_id])
        links = set()
        while queue:
            node = queue.popleft()
            for link_id, upstream in incoming.get(node, ()):
                if upstream in barriers and upstream != storage_id:
                    continue
                links.add(link_id)
                if upstream not in seen:
                    seen.add(upstream)
                    queue.append(upstream)
        feeders[storage_id] = links
    return feeders


def special_candidates(document, metrics, settings, cumulative, section, element_id,
                       baseline_storage=None):
    """Use the unchanged 1.2.4 control changes at the encountered element."""
    if section == "STORAGE":
        if not settings.allow_storage or element_id not in settings.storage_ids:
            return []
        row = next((tokens for _i, tokens, _c in document.rows("STORAGE")
                    if len(tokens) >= 6 and tokens[0] == element_id), None)
        if row is None or row[4].upper() != "TABULAR":
            return []
        # A shared area curve changes every storage that references it. Never
        # mutate an unselected storage as a side effect of the chosen one.
        if any(len(tokens) >= 6 and tokens[5] == row[5] and
               tokens[0] not in settings.storage_ids
               for _i, tokens, _c in document.rows("STORAGE")):
            return []
        baseline = (baseline_storage or {}).get(row[5])
        if baseline is None:
            baseline = {index: float(tokens[-1])
                        for index, tokens, _comment in document.rows("CURVES")
                        if len(tokens) >= 3 and tokens[0] == row[5]}
        changed = document.clone()
        updated = []
        for index, tokens, comment in document.rows("CURVES"):
            if index not in baseline or len(tokens) < 3 or tokens[0] != row[5]:
                continue
            original = baseline[index]
            if original < 0:
                continue
            current_area = float(tokens[-1])
            new_area = min(current_area * settings.storage_area_factor, original * 5.0)
            if new_area <= current_area + 1e-9:
                continue
            new_tokens = list(tokens)
            new_tokens[-1] = "{:.6f}".format(new_area)
            changed.set_tokens("CURVES", index, new_tokens, comment)
            if original > 0:
                updated.append(new_area / original)
        if not updated:
            return []
        total_factor = max(updated)
        return [("Storage {}: area totale x{:.3f} (passo x{:.3f})".format(
            element_id, total_factor, settings.storage_area_factor), changed)]
        # Upstream flooding can be relieved by a storage which itself does
        # not flood, so include the encountered storage as a local candidate.
        local_metrics = dict(metrics)
        local_metrics["flooded_nodes"] = list(set(metrics["flooded_nodes"]) | {element_id})
        label = "Storage {}:".format(element_id)
    elif section == "PUMPS":
        if not settings.allow_pumps or element_id not in settings.pump_ids:
            return []
        curve = next((tokens[4] for _i, tokens, _c in document.rows("PUMPS")
                      if len(tokens) >= 5 and tokens[0] == element_id), None)
        if not curve:
            return []
        if any(len(tokens) >= 5 and tokens[4] == curve and
               tokens[0] not in settings.pump_ids
               for _i, tokens, _c in document.rows("PUMPS")):
            return []
        local_metrics = metrics
        label = "Curva pompa {}:".format(curve)
    elif section == "ORIFICES":
        if not settings.allow_orifices or element_id not in settings.orifice_ids:
            return []
        local_metrics = metrics
        label = "Orifizio {}:".format(element_id)
    elif section == "WEIRS":
        if not settings.allow_weirs or element_id not in settings.weir_ids:
            return []
        local_metrics = metrics
        label = "Soglia {}:".format(element_id)
    else:
        return []
    return [(action, candidate) for action, candidate in
            candidate_changes(document, local_metrics, settings, cumulative)
            if action.startswith(label)]


def validate_special_selection(document, settings):
    """Reject missing/indirectly affected elements before running SWMM."""
    requests = (
        ("STORAGE", settings.storage_ids), ("PUMPS", settings.pump_ids),
        ("ORIFICES", settings.orifice_ids), ("WEIRS", settings.weir_ids),
    )
    for section, selected in requests:
        rows = {tokens[0]: (tokens, comment) for _i, tokens, comment
                in document.rows(section) if tokens}
        missing = set(selected) - set(rows)
        if missing:
            raise ValueError("ID {} inesistenti nel modello: {}".format(
                section, ", ".join(sorted(missing))))
        if section == "STORAGE":
            for element in selected:
                tokens = rows[element][0]
                if len(tokens) < 6 or tokens[4].upper() != "TABULAR":
                    raise ValueError("Lo storage {} non usa una curva TABULAR modificabile.".format(element))
                shared = [name for name, (other, _comment) in rows.items()
                          if len(other) >= 6 and other[5] == tokens[5] and name not in selected]
                if shared:
                    raise ValueError("La curva dello storage {} è condivisa con {}: selezionare anche questi storage oppure usare curve distinte.".format(
                        element, ", ".join(shared)))
        elif section == "PUMPS":
            for element in selected:
                tokens = rows[element][0]
                if len(tokens) < 5:
                    raise ValueError("La pompa {} non ha una curva valida.".format(element))
                shared = [name for name, (other, _comment) in rows.items()
                          if len(other) >= 5 and other[4] == tokens[4] and name not in selected]
                if shared:
                    raise ValueError("La curva della pompa {} è condivisa con {}: selezionare anche queste pompe oppure usare curve distinte.".format(
                        element, ", ".join(shared)))
        elif section == "ORIFICES":
            for element in selected:
                if "QMAX_LPS=" in rows[element][1].upper():
                    raise ValueError("L'orifizio {} ha QMAX_LPS: il coefficiente è vincolato e non può essere ottimizzato.".format(element))


def optimize(base_inp, initial_rpt, output_dir, settings, run_solver, progress=None):
    """Iteratively minimise hydraulic failures. ``run_solver`` runs SWMM."""
    os.makedirs(output_dir, exist_ok=True)
    current = InpDocument.read(base_inp)
    validate_special_selection(current, settings)
    if settings.allow_storage and settings.storage_area_factor < 1.05:
        raise ValueError("Il passo iterativo dello storage deve essere almeno x1.05.")
    storage_names = {tokens[5] for _i, tokens, _c in current.rows("STORAGE")
                     if len(tokens) >= 6 and tokens[0] in settings.storage_ids}
    baseline_storage = {name: {} for name in storage_names}
    for index, tokens, _comment in current.rows("CURVES"):
        if len(tokens) >= 3 and tokens[0] in baseline_storage:
            try:
                baseline_storage[tokens[0]][index] = float(tokens[-1])
            except ValueError:
                pass
    current_metrics = hydraulic_metrics(initial_rpt, settings)
    if not current_metrics["reliable"]:
        raise ValueError("Il report iniziale ha un errore di continuità del routing eccessivo: {:.2f}%.".format(
            current_metrics["continuity_error_pct"]))
    cumulative = {}
    trials = []
    simulations = 0
    best_rpt = initial_rpt
    best_out = ""
    stages = network_stages(current)
    feeder_links = storage_feeder_conduits(current, settings.storage_ids if settings.allow_storage else ())
    special_attempts = {}

    def simulate(candidate, action):
        nonlocal simulations
        simulations += 1
        stem = "trial_{:03d}".format(simulations)
        inp_path = os.path.join(output_dir, stem + ".inp")
        rpt_path = os.path.join(output_dir, stem + ".rpt")
        out_path = os.path.join(output_dir, stem + ".out")
        candidate.write(inp_path)
        run_solver(inp_path, rpt_path, out_path)
        metrics = hydraulic_metrics(rpt_path, settings)
        trial = Trial(simulations, action, metrics["score"], metrics["flood_m3"],
                      metrics["overload_pct"], False, inp_path, rpt_path, out_path)
        trials.append(trial)
        if progress:
            progress(simulations, action, metrics)
        return metrics, trial

    while not current_metrics["feasible"]:
        changed_in_pass = False
        # A flooding storage is addressed before changing any of its gravity
        # feeders, even though the feeders appear earlier in the network order.
        for section, element in stages:
            if section != "STORAGE" or not settings.allow_storage or element not in settings.storage_ids:
                continue
            key = (section, element)
            while (current_metrics["flood_by_node"].get(element, 0.0) > 1e-9 and
                   special_attempts.get(key, 0) < 50):
                candidates = special_candidates(current, current_metrics, settings,
                                                cumulative, section, element, baseline_storage)
                if not candidates:
                    break
                action, candidate = candidates[0]
                special_attempts[key] = special_attempts.get(key, 0) + 1
                metrics, trial = simulate(candidate, action)
                if (metrics["reliable"] and metrics["score"] < current_metrics["score"] - 1e-9 and
                        metrics["flood_by_node"].get(element, 0.0) <=
                        current_metrics["flood_by_node"].get(element, 0.0) + 1e-9):
                    trial.accepted = True
                    current, current_metrics = candidate, metrics
                    best_rpt, best_out = trial.rpt_path, trial.out_path
                    changed_in_pass = True
                else:
                    # An ineffective storage step is not a reason to enlarge
                    # its upstream pipes; report the unresolved constraint.
                    special_attempts[key] = 50
                    break

        protected = set().union(*(
            links for storage_id, links in feeder_links.items()
            if current_metrics["flood_by_node"].get(storage_id, 0.0) > 1e-9
        )) if feeder_links else set()
        for section, element in stages:
            if current_metrics["feasible"]:
                break
            if section == "CONDUITS":
                for link_id in element:
                    if (link_id in protected or link_id not in current_metrics["critical_links"]):
                        continue
                    diameter_candidate, upgrades = upgrade_critical_conduits(
                        current, (link_id,), settings.diameters_m)
                    if not upgrades:
                        continue
                    _name, old, new = upgrades[0]
                    action = "Incremento diametro {}: {:.3f}->{:.3f} m".format(link_id, old, new)
                    metrics, trial = simulate(diameter_candidate, action)
                    if (metrics["reliable"] and metrics["score"] < current_metrics["score"] - 1e-9 and
                            all(metrics["flood_by_node"].get(storage_id, 0.0) <=
                                current_metrics["flood_by_node"].get(storage_id, 0.0) + 1e-9
                                for storage_id, links in feeder_links.items() if link_id in links)):
                        trial.accepted = True
                        current, current_metrics = diameter_candidate, metrics
                        best_rpt, best_out = trial.rpt_path, trial.out_path
                        changed_in_pass = True
                continue

            if section == "STORAGE":
                continue

            key = (section, element)
            if special_attempts.get(key, 0) >= (50 if section == "STORAGE" else 5):
                continue
            # The chosen storage is calibrated repeatedly at this point in
            # the path before advancing downstream. Every point is capped at
            # five times its value in the initial INP, not five iterations.
            while not current_metrics["feasible"]:
                if (section == "STORAGE" and
                        current_metrics["flood_by_node"].get(element, 0.0) <= 1e-9):
                    break
                candidates = special_candidates(
                    current, current_metrics, settings, cumulative, section,
                    element, baseline_storage
                )
                if not candidates or special_attempts.get(key, 0) >= (50 if section == "STORAGE" else 5):
                    break
                action, candidate = candidates[0]
                special_attempts[key] = special_attempts.get(key, 0) + 1
                metrics, trial = simulate(candidate, action)
                if (metrics["reliable"] and metrics["score"] < current_metrics["score"] - 1e-9 and
                        (section != "STORAGE" or
                         metrics["flood_by_node"].get(element, 0.0) <=
                         current_metrics["flood_by_node"].get(element, 0.0) + 1e-9)):
                    trial.accepted = True
                    current, current_metrics = candidate, metrics
                    best_rpt, best_out = trial.rpt_path, trial.out_path
                    changed_in_pass = True
                else:
                    break
                if section != "STORAGE":
                    break

        if changed_in_pass:
            continue

        best = None
        # Preserve the 1.2.4 offset fallback only when neither pipe stretches
        # nor encountered special elements can advance further.
        candidates = [(action, candidate) for action, candidate in
                      candidate_changes(current, current_metrics, settings, cumulative)
                      if action.startswith("Offset monte ") and
                      action.split()[2].rstrip(":") not in protected]
        if not candidates:
            break
        for action, candidate in candidates:
            metrics, trial = simulate(candidate, action)
            total_diameter = sum(
                float(row[1][2]) for row in candidate.rows("XSECTIONS")
                if len(row[1]) >= 3 and row[1][1].upper() == "CIRCULAR"
            )
            rank = (0 if metrics["feasible"] else 1, metrics["score"], total_diameter)
            if best is None or rank < best[0]:
                best = (rank, candidate, metrics, trial)
        if best is None:
            break
        _rank, candidate, candidate_metrics, accepted_trial = best
        # Diameter plateaus are handled above by advancing through the finite
        # catalogue. Once no diameter can advance, an auxiliary intervention is
        # accepted only if it strictly improves the hydraulic result; otherwise
        # the available configuration cannot converge and the loop terminates.
        if candidate_metrics["score"] >= current_metrics["score"] - 1e-9:
            break
        current, current_metrics = candidate, candidate_metrics
        accepted_trial.accepted = True
        best_rpt = accepted_trial.rpt_path
        best_out = accepted_trial.out_path
        if accepted_trial.action.startswith("Offset monte "):
            link_id = accepted_trial.action.split()[2].rstrip(":")
            cumulative["offset:" + link_id] = cumulative.get("offset:" + link_id, 0.0) + settings.offset_step_m

    best_inp = os.path.join(output_dir, "modello_swmm_ottimizzato.inp")
    current.write(best_inp)
    final_rpt = os.path.join(output_dir, "modello_swmm_ottimizzato.rpt")
    final_out = os.path.join(output_dir, "modello_swmm_ottimizzato.out")
    if os.path.exists(best_rpt):
        shutil.copy2(best_rpt, final_rpt)
    if best_out and os.path.exists(best_out):
        shutil.copy2(best_out, final_out)
    csv_path = os.path.join(output_dir, "riepilogo_ottimizzazione.csv")
    with open(csv_path, "w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.writer(handle, delimiter=";")
        writer.writerow(["run", "azione", "punteggio_idraulico", "esondazione_m3", "sovraccarico_pct", "accettata", "file_inp"])
        for trial in trials:
            writer.writerow([trial.run, trial.action, trial.score, trial.flood_m3, trial.overload_pct, "SI" if trial.accepted else "NO", trial.inp_path])
    return OptimizerResult(best_inp, final_rpt if os.path.exists(final_rpt) else best_rpt, final_out if os.path.exists(final_out) else best_out, current_metrics["feasible"], simulations, trials)


def _intervention_index(base, candidate):
    """Physical intervention proxy, NOT a monetary construction estimate."""
    initial_diameters = {tokens[0]: float(tokens[2]) for _i, tokens, _c in base.rows("XSECTIONS")
                         if len(tokens) >= 3 and tokens[1].upper() == "CIRCULAR"}
    lengths = {tokens[0]: float(tokens[3]) for _i, tokens, _c in base.rows("CONDUITS")
               if len(tokens) >= 4 and _NUMBER.match(tokens[3])}
    pipe_volume = sum(
        lengths.get(tokens[0], 0.0) * math.pi / 4.0 *
        max(0.0, float(tokens[2]) ** 2 - initial_diameters[tokens[0]] ** 2)
        for _i, tokens, _c in candidate.rows("XSECTIONS")
        if len(tokens) >= 3 and tokens[0] in initial_diameters and
        tokens[1].upper() == "CIRCULAR" and _NUMBER.match(tokens[2])
    )
    original_curves = {tokens[0]: [] for _i, tokens, _c in base.rows("CURVES")
                       if len(tokens) >= 4 and tokens[1].upper() == "STORAGE"}
    for document, sign in ((base, -1), (candidate, 1)):
        for _i, tokens, _c in document.rows("CURVES"):
            if tokens and tokens[0] in original_curves and len(tokens) >= 3:
                try:
                    original_curves[tokens[0]].append((sign, float(tokens[-2]), float(tokens[-1])))
                except ValueError:
                    continue
    storage_volume = 0.0
    for values in original_curves.values():
        for sign in (-1, 1):
            points = sorted((depth, area) for side, depth, area in values if side == sign)
            storage_volume += sign * sum(
                (points[i][0] - points[i - 1][0]) * (points[i][1] + points[i - 1][1]) / 2.0
                for i in range(1, len(points)))
    selected_pump_curves = {tokens[4] for _i, tokens, _c in base.rows("PUMPS")
                            if len(tokens) >= 5}
    base_curve_rows = {i: tokens for i, tokens, _c in base.rows("CURVES") if tokens}
    changed_controls = sum(
        tokens[0] in selected_pump_curves and i in base_curve_rows and
        tokens[-1] != base_curve_rows[i][-1]
        for i, tokens, _c in candidate.rows("CURVES") if tokens)
    for section in ("ORIFICES", "WEIRS"):
        old = {tokens[0]: tokens for _i, tokens, _c in base.rows(section) if tokens}
        changed_controls += sum(tokens[0] in old and tokens != old[tokens[0]]
                                for _i, tokens, _c in candidate.rows(section) if tokens)
    old_weirs = {tokens[0] for _i, tokens, _c in base.rows("WEIRS") if tokens}
    old_sections = {tokens[0]: tokens for _i, tokens, _c in base.rows("XSECTIONS")
                    if tokens and tokens[0] in old_weirs}
    changed_controls += sum(tokens[0] in old_sections and tokens != old_sections[tokens[0]]
                            for _i, tokens, _c in candidate.rows("XSECTIONS") if tokens)
    return max(0.0, pipe_volume) + max(0.0, storage_volume) + changed_controls


def _flow_limited_outlets_ok(document, rpt_path):
    """Do not claim feasibility when an outlet exceeds its INP QMAX_LPS tag."""
    links, _nodes = parse_report(rpt_path)
    for _i, tokens, comment in document.rows("ORIFICES"):
        match = re.search(r"QMAX_LPS\s*=\s*([0-9.eE+-]+)", comment, re.IGNORECASE)
        if not tokens or not match:
            continue
        peak = (links.get(tokens[0]) or {}).get("qmax")
        if peak is None or peak > float(match.group(1)) * 1.01 + 1e-9:
            return False
    return True


def _special_bounds_ok(base, candidate, settings):
    """Enforce user-authorised control caps against the untouched base INP."""
    pump_curves = {tokens[4] for _i, tokens, _c in base.rows("PUMPS")
                   if len(tokens) >= 5 and tokens[0] in settings.pump_ids}
    baseline = {i: tokens for i, tokens, _c in base.rows("CURVES") if tokens}
    for i, tokens, _c in candidate.rows("CURVES"):
        if tokens and tokens[0] in pump_curves and i in baseline:
            if float(tokens[-1]) > float(baseline[i][-1]) * settings.pump_max_factor + 1e-8:
                return False
    baseline_xsections = {tokens[0]: tokens for _i, tokens, _c in base.rows("XSECTIONS") if tokens}
    for _i, tokens, _c in candidate.rows("XSECTIONS"):
        if len(tokens) >= 3 and tokens[0] in settings.weir_ids and tokens[0] in baseline_xsections:
            if float(tokens[2]) > float(baseline_xsections[tokens[0]][2]) * settings.weir_max_factor + 1e-8:
                return False
    for _i, tokens, _c in candidate.rows("ORIFICES"):
        if len(tokens) >= 6 and tokens[0] in settings.orifice_ids:
            if float(tokens[5]) > settings.orifice_max_coeff + 1e-8:
                return False
    return True


def optimize_system(base_inp, initial_rpt, output_dir, settings, run_solver, progress=None):
    """Bounded whole-network search with storage priority and coupled alternatives.

    Keep several complete INPs in the frontier instead of committing every
    pipe step. All comparisons use SWMM runs of the *entire* model; hydraulics
    determine eligibility, intervention size breaks ties among feasible plans.
    """
    if settings.max_simulations < 1 or settings.search_width < 1:
        raise ValueError("Impostare almeno una simulazione e una configurazione candidata.")
    os.makedirs(output_dir, exist_ok=True)
    base = InpDocument.read(base_inp)
    validate_special_selection(base, settings)
    initial = hydraulic_metrics(initial_rpt, settings)
    if not initial["reliable"]:
        raise ValueError("Il report iniziale supera la soglia di continuità del routing.")
    if not _flow_limited_outlets_ok(base, initial_rpt):
        raise ValueError("Il report iniziale supera una portata QMAX_LPS: verificare o ricalibrare l'orifizio prima dell'ottimizzazione.")
    baseline_storage = {}
    selected_curves = {tokens[5] for _i, tokens, _c in base.rows("STORAGE")
                       if len(tokens) >= 6 and settings.allow_storage and tokens[0] in settings.storage_ids}
    for _i, tokens, _c in base.rows("CURVES"):
        if len(tokens) >= 3 and tokens[0] in selected_curves:
            baseline_storage.setdefault(tokens[0], {})[_i] = float(tokens[-1])
    stages = network_stages(base)
    feeders = storage_feeder_conduits(base, settings.storage_ids if settings.allow_storage else ())
    frontier = [(base, initial, initial_rpt, "", 0.0)]
    best_feasible = (base, initial, initial_rpt, "", 0.0) if initial["feasible"] else None
    best_partial = frontier[0]
    visited = {hashlib.sha256(base.to_text().encode()).hexdigest()}
    trials = []

    def alternatives(document, metrics):
        # Feeder pipes remain protected while further storage volume can be
        # tested. Once the authorised 5x limit is exhausted, test a remaining
        # locally critical feeder individually and reject it if B5 worsens.
        protected = set().union(*(
            links for sid, links in feeders.items()
            if metrics["flood_by_node"].get(sid, 0) > 1e-9 and
            special_candidates(document, metrics, settings, {}, "STORAGE", sid,
                               baseline_storage)
        )) if feeders else set()
        volume_available = False
        # Explore several step lengths after a numerically unstable storage
        # trial; no single rejected trial exhausts the fivefold area allowance.
        for section, element in stages:
            if section != "STORAGE" or metrics["flood_by_node"].get(element, 0.0) <= 1e-9:
                continue
            for factor in sorted({settings.storage_area_factor,
                                  max(1.05, settings.storage_area_factor ** 0.5), 1.05}, reverse=True):
                variant = OptimizerSettings(**{**settings.__dict__, "storage_area_factor": factor})
                for label, candidate in special_candidates(
                        document, metrics, variant, {}, section, element, baseline_storage):
                    volume_available = True
                    yield label, candidate
        # Only modify special elements which the user explicitly selected.
        for section, element in stages:
            if section in ("PUMPS", "ORIFICES", "WEIRS"):
                for action, candidate in special_candidates(
                        document, metrics, settings, {}, section, element, baseline_storage):
                    yield action, candidate
        # Preserve simulation budget for the selected flooding storage. Once
        # its area cannot advance, include pipes and coupled configurations.
        if volume_available:
            return
        pipe_count = 0
        for section, element in stages:
            if section != "CONDUITS":
                continue
            for link_id in element:
                if link_id in protected or link_id not in metrics["critical_links"]:
                    continue
                candidate, upgrades = upgrade_critical_conduits(document, (link_id,), settings.diameters_m)
                if upgrades:
                    _link, old, new = upgrades[0]
                    yield "Condotta {}: {:.3f}->{:.3f} m".format(link_id, old, new), candidate
                    pipe_count += 1
                    if pipe_count >= 24:
                        return

    while frontier and len(trials) < settings.max_simulations:
        next_states = []
        for document, metrics, _rpt, _out, _cost in frontier:
            for action, candidate in alternatives(document, metrics):
                if not _special_bounds_ok(base, candidate, settings):
                    continue
                fingerprint = hashlib.sha256(candidate.to_text().encode()).hexdigest()
                if fingerprint in visited:
                    continue
                visited.add(fingerprint)
                number = len(trials) + 1
                stem = "trial_{:03d}".format(number)
                inp_path = os.path.join(output_dir, stem + ".inp")
                rpt_path = os.path.join(output_dir, stem + ".rpt")
                out_path = os.path.join(output_dir, stem + ".out")
                candidate.write(inp_path)
                run_solver(inp_path, rpt_path, out_path)
                result = hydraulic_metrics(rpt_path, settings)
                cost = _intervention_index(base, candidate)
                trial = Trial(number, action, result["score"], result["flood_m3"],
                              result["overload_pct"], False, inp_path, rpt_path, out_path)
                trials.append(trial)
                if progress:
                    progress(number, action, result)
                if not result["reliable"]:
                    trial.reason = "Errore di continuità del routing oltre soglia"
                elif not _flow_limited_outlets_ok(candidate, rpt_path):
                    trial.reason = "Portata QMAX_LPS superata"
                else:
                    trial.reason = "Alternativa simulata sull'intera rete"
                if result["reliable"] and _flow_limited_outlets_ok(candidate, rpt_path):
                    # Even where a feeder may be considered at the storage
                    # cap, it must not shift a worse flood into that storage.
                    if action.startswith("Condotta "):
                        link_id = action.split()[1].rstrip(":")
                        if any(result["flood_by_node"].get(sid, 0.0) >
                               metrics["flood_by_node"].get(sid, 0.0) + 1e-9
                               for sid, links in feeders.items() if link_id in links):
                            trial.reason = "Esondazione storage a valle peggiorata"
                            continue
                    state = (candidate, result, rpt_path, out_path, cost)
                    if result["feasible"]:
                        if best_feasible is None or cost < best_feasible[4] - 1e-9:
                            best_feasible = state
                            trial.reason = "Migliore soluzione ammissibile provvisoria"
                    elif result["score"] < best_partial[1]["score"] - 1e-9:
                        best_partial = state
                        trial.reason = "Migliore miglioramento idraulico provvisorio"
                    # Limited intermediate regression allows interacting
                    # interventions, without drifting arbitrarily far.
                    if (not result["feasible"] and
                            result["score"] <= max(initial["score"], metrics["score"]) * 1.10 + 1e-9):
                        next_states.append(state)
                if len(trials) >= settings.max_simulations:
                    break
            if len(trials) >= settings.max_simulations:
                break
        # Different full INPs can each lead to a useful coupled solution.
        next_states.sort(key=lambda state: (state[1]["score"], state[4]))
        frontier = next_states[:settings.search_width]

    winner = best_feasible or best_partial
    document, metrics, report, out, cost = winner
    for trial in trials:
        trial.accepted = os.path.abspath(trial.rpt_path) == os.path.abspath(report)
        if trial.accepted:
            trial.reason = "Soluzione finale selezionata"
    best_inp = os.path.join(output_dir, "modello_swmm_ottimizzato.inp")
    final_rpt = os.path.join(output_dir, "modello_swmm_ottimizzato.rpt")
    final_out = os.path.join(output_dir, "modello_swmm_ottimizzato.out")
    document.write(best_inp)
    if os.path.isfile(report) and os.path.abspath(report) != os.path.abspath(final_rpt):
        shutil.copy2(report, final_rpt)
    if out and os.path.isfile(out):
        shutil.copy2(out, final_out)
    with open(os.path.join(output_dir, "riepilogo_ottimizzazione.csv"), "w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.writer(handle, delimiter=";")
        writer.writerow(("run", "azione", "punteggio_idraulico", "esondazione_m3",
                         "sovraccarico_pct", "accettata", "file_inp", "errore_continuita_pct",
                         "indice_intervento_non_CME", "motivo"))
        for trial in trials:
            report_metrics = hydraulic_metrics(trial.rpt_path, settings)
            writer.writerow((trial.run, trial.action, trial.score, trial.flood_m3,
                             trial.overload_pct, "SI" if trial.accepted else "NO", trial.inp_path,
                             report_metrics["continuity_error_pct"],
                             _intervention_index(base, InpDocument.read(trial.inp_path)), trial.reason))
    return OptimizerResult(best_inp, final_rpt if os.path.isfile(final_rpt) else report,
                           final_out if os.path.isfile(final_out) else out,
                           metrics["feasible"], len(trials), trials)
